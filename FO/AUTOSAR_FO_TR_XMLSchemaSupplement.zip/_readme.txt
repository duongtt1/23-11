Document Title:                 Supplementary material of the AUTOSAR XML Schema
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 649
Document Status:                published
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       R23-11
Date:                           2023-11-23

Covered Standards:              4.9.0

This archive contains the following files:

readme.txt
    This file

AUTOSAR_00052_COMPACT.xsd
    This AUXILIARY file provides a compacted AUTOSAR XML schema which is 
    optimized for performance. In particular the named groups are replaced
    by its contents. Also nested unnamed groups are optimized such that 
    an XML parser does not need to evaluate too many options.

AUTOSAR_00052_STRICT.xsd
    This AUXILIARY file provides a AUTOSAR XML schema which strictly follows
    the multiplicity in the meta-model. This may be used for more strict 
    validation of the structures.

AUTOSAR_00052_STRICT_COMPACT.xsd
    This AUXILIARY file provides a compacted strict AUTOSAR XML schema which is 
    optimized for performance. In particular the named groups are replaced
    by its contents. Also nested unnamed groups are optimized such that 
    an XML parser does not need to evaluate too many options.

AUTOSAR_00052.css
    This AUXILIARY file provides an initial css stylesheet for visualization of 
    AUTOSAR XML files 

AUTOSAR_00052_PRIMITIVE_TEST.xsd
    This AUXILIARY file provides a test XML schema to test regular expressions 
    used in the xsd:simpleTypes of the original AUTOSAR XML Schema. The user 
    may write test XML files with various expressions for xsd:simpleType values
    and validate those XML files against this test XML schema to determine if
    the used expressions would be valid in an regular ARXML file.

xml.xsd
    This is the schema for the xml namespace as provided by W3C.
    For xml.xsd the W3C license applies, which can be found on
    https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document:

        License

        By obtaining and/or copying this work, you (the licensee) agree that you have read, understood, and will comply with the following terms and conditions.

        Permission to copy, modify, and distribute this work, with or without modification, for any purpose and without fee or royalty is hereby granted, provided that you include the following on ALL copies of the work or portions thereof, including modifications:

            The full text of this NOTICE in a location viewable to users of the redistributed or derivative work.
            Any pre-existing intellectual property disclaimers, notices, or terms and conditions. If none exist, the W3C Software and Document Short Notice should be included.
            Notice of any changes or modifications, through a copyright statement on the new code or document such as "This software or document includes material copied from or derived from [title and URI of the W3C document]. Copyright © [YEAR] W3C® (MIT, ERCIM, Keio, Beihang)." 

        Disclaimers

        THIS WORK IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENT WILL NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.

        COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE SOFTWARE OR DOCUMENT.

        The name and trademarks of copyright holders may NOT be used in advertising or publicity pertaining to the work without specific, written prior permission. Title to copyright in this work will at all times remain with copyright holders.


The XSD and CSS files contained in AUTOSAR_TR_XMLSchemaSupplement.zip are             
auxiliary files, i.e. their usage is not enforced by AUTOSAR in any way.
