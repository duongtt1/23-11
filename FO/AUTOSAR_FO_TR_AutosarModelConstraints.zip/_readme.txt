Document Title:                 Collection of constraints on AUTOSAR M1 models
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 635
Document Status:                published
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       R23-11
Date:                           2023-11-23


Please see chapter 1 of the included PDF files for information about this 
document.
