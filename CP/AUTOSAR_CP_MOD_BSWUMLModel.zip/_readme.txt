Document Title:                 Basic Software UML Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 052
Document Status:                published
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       R23-11
Date:                           2023-11-23
